import mysql.connector

# Establish a connection to MySQL
conn = mysql.connector.connect(
    user="root",
    password="ChicagoPD!311",
    database="financial_database_updated"  # Change to your actual database name
)

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

# Report 1: Number of Clients Added Monthly
query_1 = """
    SELECT YEAR(Transaction.date) AS Year, MONTH(Transaction.date) AS Month, COUNT(Client.client_id) AS New_Clients_Added
    FROM Transaction
    JOIN Client ON Transaction.client_id = Client.client_id
    WHERE Transaction.date >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)
    GROUP BY Year, Month
    ORDER BY Year DESC, Month DESC;
"""

cursor.execute(query_1)
result_1 = cursor.fetchall()

print("Report 1: Number of Clients Added Monthly")
for row in result_1:
    print(row)

# Report 2: Average Amount of Assets per Client
query_2 = """
    SELECT AVG(Asset.value) AS Average_Asset_Value
    FROM Asset;
"""

cursor.execute(query_2)
result_2 = cursor.fetchone()

print("\nReport 2: Average Amount of Assets per Client")
print("Average Asset Value:", result_2[0])

# Report 3: Clients with High Transaction Frequency
query_3 = """
    SELECT Client.client_id, COUNT(*) AS Monthly_Transactions
    FROM Transaction
    JOIN Client ON Transaction.client_id = Client.client_id
    GROUP BY Client.client_id
    HAVING COUNT(*) > 10;
"""

cursor.execute(query_3)
result_3 = cursor.fetchall()

print("\nReport 3: Clients with High Transaction Frequency")
for row in result_3:
    print(row)

# Close cursor and connection
cursor.close()
conn.close()
